# Electrical Distribution Load & Voltage-Drop Analyzer

Independent electrical engineering project built in Python.

## Project purpose

This program models a simplified low-voltage electrical distribution system with multiple electrical loads connected to a 120 V source through resistive feeders.

The purpose is to study how increasing electrical demand affects:

- branch current
- delivered load voltage
- feeder voltage drop
- conductor power loss
- system efficiency

The model includes three operating conditions:

- Light Load: 75% of nominal demand
- Normal Load: 100% of nominal demand
- Heavy Load: 150% of nominal demand

It also sweeps demand from 50% to 180% of nominal values and produces graphs showing system behavior.

---

## System model

The default system contains three branches:

| Load | Nominal Power | Feeder Resistance |
|---|---:|---:|
| Lighting / Electronics | 300 W | 0.30 ohm |
| General Load | 600 W | 0.50 ohm |
| High-Demand Load | 900 W | 0.70 ohm |

Source voltage:

120 V

The numbers are simplified project values chosen to make voltage-drop and conductor-loss behavior easy to observe.

---

## Electrical concepts used

### Electrical power

P = VI

Therefore:

I = P / V

### Feeder voltage drop

V_drop = IR

### Delivered voltage

V_load = V_source - V_drop

### Resistive conductor loss

P_loss = I^2 R

This is important because conductor loss grows approximately with the square of current.

If current doubles while resistance remains unchanged, resistive loss becomes roughly four times larger.

### System efficiency

Efficiency = useful load power / source power

The program reports this value as a percentage.

---

## Constant-power branch model

Instead of estimating current only from the nominal source voltage, this project uses a simple constant-power load model.

The branch equations are:

V_load = V_source - IR

P_load = V_load I

Since:

I = P_load / V_load

the equations combine into:

V_load^2 - V_source V_load + P_load R = 0

The physically useful high-voltage solution is:

V_load =
(V_source + sqrt(V_source^2 - 4 P_load R)) / 2

The current is then calculated from:

I = P_load / V_load

This means current rises slightly when feeder voltage drop causes the delivered voltage to fall.

---

## What the program produces

### Terminal output

For every operating scenario, the program prints:

- source voltage
- requested load power
- feeder resistance
- branch current
- delivered voltage
- voltage drop in volts
- voltage drop as a percentage
- feeder power loss
- branch efficiency
- total system current
- total feeder losses
- total source power
- overall efficiency

A warning is printed when voltage drop exceeds the project's 3% analysis threshold.

The 3% value is being used as a project/design threshold for comparison and is not presented as a universal electrical-code requirement.

### CSV output

The program creates:

`distribution_results.csv`

This contains numerical results for each load under each operating scenario.

### Graph 1

`voltage_vs_demand.png`

Shows delivered load voltage as electrical demand increases.

### Graph 2

`loss_vs_demand.png`

Shows how total feeder power loss changes as electrical demand increases.

---

## Requirements

Python 3 and Matplotlib.

Install Matplotlib with:

```bash
python -m pip install matplotlib
```

If Matplotlib is already installed from another project, nothing else needs to be installed.

---

## Run the project

From the project folder:

```bash
python main.py
```

The program will:

1. analyze light, normal, and heavy load conditions
2. print the results
3. save a CSV file
4. display the voltage graph
5. display the power-loss graph
6. save both graphs as PNG images

Important: when the first graph appears, close the graph window so the program can continue to the second graph.

---

## Suggested experiments

Try changing:

- `SOURCE_VOLTAGE`
- nominal load powers
- feeder resistance
- scenario demand multipliers
- voltage-drop warning threshold

Examples:

1. Double a feeder resistance and observe the delivered voltage.
2. Double a load's power and observe how conductor loss changes.
3. Reduce feeder resistance and compare system efficiency.
4. Increase the heavy-load multiplier and observe which branch first exceeds the project voltage-drop threshold.

---

## Main engineering lesson

As electrical demand increases, branch current increases.

Higher current creates:

- greater feeder voltage drop because V_drop = IR
- much greater conductor loss because P_loss = I^2 R

This makes feeder resistance and load current important design variables in electrical distribution systems.

---

## Resume entry

**Electrical Distribution Load & Voltage-Drop Analyzer | Python, Matplotlib**

- Developed a Python model of a multi-load low-voltage electrical distribution system to evaluate current demand, feeder voltage drop, and delivered load voltage.
- Calculated resistive conductor losses and system efficiency across light, normal, and heavy operating conditions.
- Simulated increasing electrical demand to identify conditions producing excessive voltage drop and higher energy loss.
- Visualized voltage regulation and conductor-loss trends using Matplotlib and exported scenario results to CSV for comparison.

---

## Interview summary

A concise way to describe the project:

> I built a Python model of a simplified electrical distribution system with several loads and resistive feeders. The program calculates branch current, delivered voltage, voltage drop, conductor losses, and overall efficiency under different demand levels. I also swept the load from light to heavy demand and graphed how voltage regulation and I-squared-R losses changed as current increased.
