import math
import csv
import matplotlib.pyplot as plt


# =========================================================
# PROJECT SETTINGS
# =========================================================

SOURCE_VOLTAGE = 120.0

# Voltage-drop warning threshold used for this project.
# This is a project/design threshold, not a claim about a universal code requirement.
VOLTAGE_DROP_WARNING_PERCENT = 3.0

# Each tuple contains:
# (load name, nominal power in watts, total feeder resistance in ohms)
LOADS = [
    ("Lighting / Electronics", 300.0, 0.30),
    ("General Load", 600.0, 0.50),
    ("High-Demand Load", 900.0, 0.70),
]

# Operating scenarios. A multiplier of 1.50 means 150% of nominal demand.
SCENARIOS = {
    "Light Load": 0.75,
    "Normal Load": 1.00,
    "Heavy Load": 1.50,
}


# =========================================================
# ELECTRICAL CALCULATION FUNCTIONS
# =========================================================

def solve_constant_power_branch(source_voltage, load_power, feeder_resistance):
    """
    Solve a simple branch consisting of:
        ideal voltage source -> resistive feeder -> constant-power load

    The load draws enough current to receive approximately the requested
    load power at its delivered voltage.

    Relationships:
        V_load = V_source - I * R
        P_load = V_load * I

    Substituting I = P_load / V_load gives:
        V_load^2 - V_source*V_load + P_load*R = 0

    The physically useful high-voltage solution is:
        V_load = (V_source + sqrt(V_source^2 - 4*P_load*R)) / 2
    """

    if load_power < 0:
        raise ValueError("Load power cannot be negative.")

    if feeder_resistance < 0:
        raise ValueError("Feeder resistance cannot be negative.")

    if load_power == 0:
        return {
            "load_power_w": 0.0,
            "current_a": 0.0,
            "delivered_voltage_v": source_voltage,
            "voltage_drop_v": 0.0,
            "voltage_drop_percent": 0.0,
            "feeder_loss_w": 0.0,
            "source_power_w": 0.0,
            "branch_efficiency_percent": 100.0,
        }

    # If feeder resistance is zero, there is no voltage drop or conductor loss.
    if feeder_resistance == 0:
        current = load_power / source_voltage
        return {
            "load_power_w": load_power,
            "current_a": current,
            "delivered_voltage_v": source_voltage,
            "voltage_drop_v": 0.0,
            "voltage_drop_percent": 0.0,
            "feeder_loss_w": 0.0,
            "source_power_w": load_power,
            "branch_efficiency_percent": 100.0,
        }

    discriminant = source_voltage**2 - 4 * load_power * feeder_resistance

    if discriminant < 0:
        raise ValueError(
            "The selected power and feeder resistance do not produce a "
            "real operating point in this simplified constant-power model."
        )

    delivered_voltage = (
        source_voltage + math.sqrt(discriminant)
    ) / 2

    current = load_power / delivered_voltage
    voltage_drop = source_voltage - delivered_voltage

    feeder_loss = current**2 * feeder_resistance
    source_power = source_voltage * current

    voltage_drop_percent = 100 * voltage_drop / source_voltage
    branch_efficiency = 100 * load_power / source_power

    return {
        "load_power_w": load_power,
        "current_a": current,
        "delivered_voltage_v": delivered_voltage,
        "voltage_drop_v": voltage_drop,
        "voltage_drop_percent": voltage_drop_percent,
        "feeder_loss_w": feeder_loss,
        "source_power_w": source_power,
        "branch_efficiency_percent": branch_efficiency,
    }


def analyze_scenario(name, demand_multiplier):
    """
    Analyze every branch for one system operating scenario.
    """

    results = []

    total_load_power = 0.0
    total_source_power = 0.0
    total_feeder_loss = 0.0
    total_source_current = 0.0

    for load_name, nominal_power, feeder_resistance in LOADS:
        requested_power = nominal_power * demand_multiplier

        branch = solve_constant_power_branch(
            SOURCE_VOLTAGE,
            requested_power,
            feeder_resistance,
        )

        branch["scenario"] = name
        branch["load_name"] = load_name
        branch["nominal_power_w"] = nominal_power
        branch["demand_multiplier"] = demand_multiplier
        branch["feeder_resistance_ohm"] = feeder_resistance

        results.append(branch)

        total_load_power += branch["load_power_w"]
        total_source_power += branch["source_power_w"]
        total_feeder_loss += branch["feeder_loss_w"]
        total_source_current += branch["current_a"]

    system_efficiency = (
        100 * total_load_power / total_source_power
        if total_source_power > 0
        else 100.0
    )

    summary = {
        "scenario": name,
        "demand_multiplier": demand_multiplier,
        "total_load_power_w": total_load_power,
        "total_source_power_w": total_source_power,
        "total_feeder_loss_w": total_feeder_loss,
        "total_source_current_a": total_source_current,
        "system_efficiency_percent": system_efficiency,
    }

    return results, summary


# =========================================================
# OUTPUT FUNCTIONS
# =========================================================

def print_scenario(results, summary):
    print("\n" + "=" * 72)
    print(f"{summary['scenario'].upper()}  "
          f"({summary['demand_multiplier'] * 100:.0f}% OF NOMINAL DEMAND)")
    print("=" * 72)
    print(f"Source voltage: {SOURCE_VOLTAGE:.1f} V")

    for branch in results:
        print("\n" + branch["load_name"])
        print("-" * len(branch["load_name"]))

        print(f"Requested load power: "
              f"{branch['load_power_w']:.2f} W")

        print(f"Feeder resistance: "
              f"{branch['feeder_resistance_ohm']:.3f} ohm")

        print(f"Branch current: "
              f"{branch['current_a']:.3f} A")

        print(f"Delivered voltage: "
              f"{branch['delivered_voltage_v']:.2f} V")

        print(f"Voltage drop: "
              f"{branch['voltage_drop_v']:.2f} V "
              f"({branch['voltage_drop_percent']:.2f}%)")

        print(f"Feeder power loss: "
              f"{branch['feeder_loss_w']:.2f} W")

        print(f"Branch efficiency: "
              f"{branch['branch_efficiency_percent']:.2f}%")

        if branch["voltage_drop_percent"] > VOLTAGE_DROP_WARNING_PERCENT:
            print(
                f"WARNING: Voltage drop exceeds the project's "
                f"{VOLTAGE_DROP_WARNING_PERCENT:.1f}% threshold."
            )

    print("\nSYSTEM SUMMARY")
    print("--------------")
    print(f"Total load power: "
          f"{summary['total_load_power_w']:.2f} W")

    print(f"Total source current: "
          f"{summary['total_source_current_a']:.3f} A")

    print(f"Total feeder losses: "
          f"{summary['total_feeder_loss_w']:.2f} W")

    print(f"Total source power: "
          f"{summary['total_source_power_w']:.2f} W")

    print(f"Overall system efficiency: "
          f"{summary['system_efficiency_percent']:.2f}%")


def save_results_to_csv(all_results, filename="distribution_results.csv"):
    fieldnames = [
        "scenario",
        "load_name",
        "demand_multiplier",
        "nominal_power_w",
        "load_power_w",
        "feeder_resistance_ohm",
        "current_a",
        "delivered_voltage_v",
        "voltage_drop_v",
        "voltage_drop_percent",
        "feeder_loss_w",
        "source_power_w",
        "branch_efficiency_percent",
    ]

    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()

        for row in all_results:
            writer.writerow({key: row[key] for key in fieldnames})


# =========================================================
# PLOTTING FUNCTIONS
# =========================================================

def create_voltage_plot():
    """
    Sweep demand from 50% to 180% of nominal and plot delivered voltage.
    """

    multipliers = [
        0.50 + 0.05 * i
        for i in range(27)
    ]

    for load_name, nominal_power, feeder_resistance in LOADS:
        delivered_voltages = []

        for multiplier in multipliers:
            requested_power = nominal_power * multiplier

            branch = solve_constant_power_branch(
                SOURCE_VOLTAGE,
                requested_power,
                feeder_resistance,
            )

            delivered_voltages.append(
                branch["delivered_voltage_v"]
            )

        percentages = [100 * value for value in multipliers]

        plt.plot(
            percentages,
            delivered_voltages,
            label=load_name
        )

    warning_voltage = SOURCE_VOLTAGE * (
        1 - VOLTAGE_DROP_WARNING_PERCENT / 100
    )

    plt.axhline(
        warning_voltage,
        linestyle="--",
        label=f"{VOLTAGE_DROP_WARNING_PERCENT:.0f}% drop threshold"
    )

    plt.xlabel("Demand (% of nominal)")
    plt.ylabel("Delivered Voltage (V)")
    plt.title("Delivered Voltage vs. Electrical Demand")
    plt.grid()
    plt.legend()
    plt.tight_layout()
    plt.savefig("voltage_vs_demand.png", dpi=200)
    plt.show()


def create_loss_plot():
    """
    Sweep system demand and plot total feeder power loss.
    """

    multipliers = [
        0.50 + 0.05 * i
        for i in range(27)
    ]

    percentages = []
    total_losses = []

    for multiplier in multipliers:
        percentages.append(100 * multiplier)

        system_loss = 0.0

        for _, nominal_power, feeder_resistance in LOADS:
            requested_power = nominal_power * multiplier

            branch = solve_constant_power_branch(
                SOURCE_VOLTAGE,
                requested_power,
                feeder_resistance,
            )

            system_loss += branch["feeder_loss_w"]

        total_losses.append(system_loss)

    plt.plot(percentages, total_losses)

    plt.xlabel("Demand (% of nominal)")
    plt.ylabel("Total Feeder Loss (W)")
    plt.title("Conductor Power Loss vs. Electrical Demand")
    plt.grid()
    plt.tight_layout()
    plt.savefig("loss_vs_demand.png", dpi=200)
    plt.show()


# =========================================================
# MAIN PROGRAM
# =========================================================

def main():
    print("LOW-VOLTAGE ELECTRICAL DISTRIBUTION ANALYZER")
    print("============================================")
    print(
        "This project evaluates current, delivered voltage, "
        "voltage drop, feeder losses, and system efficiency."
    )

    all_results = []

    for scenario_name, multiplier in SCENARIOS.items():
        results, summary = analyze_scenario(
            scenario_name,
            multiplier
        )

        all_results.extend(results)
        print_scenario(results, summary)

    save_results_to_csv(all_results)

    print("\nSaved numerical results to: distribution_results.csv")

    print("\nGenerating delivered-voltage graph...")
    create_voltage_plot()

    print("\nGenerating feeder-loss graph...")
    create_loss_plot()

    print("\nSaved graphs:")
    print("  voltage_vs_demand.png")
    print("  loss_vs_demand.png")

    print("\nAnalysis complete.")


if __name__ == "__main__":
    main()
